<?php 
// $servername = "127.0.0.1:3308";
// $username = "root";
// $password = "";
// $db = "test";

$mysqli = new mysqli("php-database.cicrulv4urjd.us-east-1.rds.amazonaws.com","admin", "shreyash","test");

if ($mysqli -> connect_error) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
